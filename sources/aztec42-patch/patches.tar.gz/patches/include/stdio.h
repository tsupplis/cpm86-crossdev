--- include/stdio.h	2021-10-21 22:56:04.000000000 +0100
+++ ../../../aztec42/include/stdio.h	2021-10-21 15:17:54.000000000 +0100
@@ -36,9 +36,9 @@
 extern FILE Cbuffs[];
 
 #ifndef __NOPROTO__
-FILE *fopen(char *name, char *mode);
-FILE *freopen(char *name, char *mode, FILE *stream);
-FILE *fdopen(int fd, char *mode);
+FILE *fopen(const char *name, const char *mode);
+FILE *freopen(const char *name, const char *mode, FILE *stream);
+FILE *fdopen(int fd, const char *mode);
 int fseek(FILE *stream, long pos, int whence);
 long ftell(FILE *stream);
 int remove(const char *filename);
@@ -47,7 +47,6 @@
 long ftell();
 #endif
 
-
 #define stdin (&Cbuffs[0])
 #define stdout (&Cbuffs[1])
 #define stderr (&Cbuffs[2])
