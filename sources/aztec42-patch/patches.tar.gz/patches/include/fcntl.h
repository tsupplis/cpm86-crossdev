--- include/fcntl.h	2021-10-21 22:56:04.000000000 +0100
+++ ../../../aztec42/include/fcntl.h	2021-10-21 15:17:54.000000000 +0100
@@ -1,3 +1,6 @@
+#ifndef __FCNTL_H
+#define __FCNTL_H
+
 #define O_RDONLY	0
 #define O_WRONLY	1
 #define O_RDWR		2
@@ -11,3 +14,10 @@
 #define O_TRUNC		0x0200
 #define O_EXCL		0x0400
 #define O_APPEND	0x0800
+
+#define OS_CPM86 0
+#define OS_MSDOS11 1
+#define OS_MSDOS20 2
+int os();
+
+#endif
