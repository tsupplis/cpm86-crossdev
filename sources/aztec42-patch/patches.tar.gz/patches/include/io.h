--- include/io.h	2021-10-21 22:56:04.000000000 +0100
+++ ../../../aztec42/include/io.h	2021-10-21 15:17:54.000000000 +0100
@@ -1,3 +1,5 @@
+#ifndef __IO_H
+#define __IO_H
 /* Copyright (C) 1982 by Manx Software Systems */
 /*
  * if MAXCHAN is changed then the initialization of chantab in croot.c
@@ -47,7 +49,22 @@
 } ;
 extern struct channel chantab[MAXCHAN];
 
-struct fcb {
+struct dos_fcb {
+	char f_driv;
+	char f_name[8];
+	char f_type[3];
+	unsigned f_curblk;		
+	unsigned f_reclen;
+	long f_size;	
+	unsigned f_date;	
+	unsigned f_lastwrite;	
+	char f_resv[8];	
+	char f_currec;	
+	long f_record;	
+	char f_overfl;
+};
+
+struct cpm_fcb {
 	char f_driv;
 	char f_name[8];
 	char f_type[3];
@@ -56,11 +73,15 @@
 	char f_rc;
 	char f_sydx[16];
 	char f_cr;
-	unsigned f_record; char f_overfl;
+	unsigned f_record; 
+	char f_overfl;
 };
 
 struct fcbtab {
-	struct fcb fcb;
+	union {
+		struct cpm_fcb cpm;
+		struct dos_fcb dos;
+    } fcb;
 	char offset;
 	char flags;
 	char user;
@@ -80,3 +101,4 @@
 #define SETREC	36
 
 #define Wrkbuf ((char *)0x80)
+#endif
