--- src/dos11/open.c	2021-10-21 22:57:07.000000000 +0100
+++ ../../../aztec42/src/dos11/open.c	2021-10-21 17:20:19.000000000 +0100
@@ -4,9 +4,12 @@
 #include "io.h"
 
 #define MAXFILE	8	/* maximum number of open DISK files */
-int badfd(), noper();
+int badfd();
+
 static int fileop();
 
+int noper();
+
 static struct device condev = { 2, 2, 1, 0, noper };
 static struct device filedev= { 1, 1, 0, 1, fileop };
 
@@ -101,8 +104,8 @@
 	}
 	
 	fp->flags = 1;
-	fp->fcb.f_record = (flag&O_APPEND) ? fp->fcb.f_size : 0L;
-	fp->fcb.f_reclen = 1;
+	fp->fcb.dos.f_record = (flag&O_APPEND) ? fp->fcb.dos.f_size : 0L;
+	fp->fcb.dos.f_reclen = 1;
 	chp->c_arg = fp;
 	chp->c_close = filecl;
 	return 0;
