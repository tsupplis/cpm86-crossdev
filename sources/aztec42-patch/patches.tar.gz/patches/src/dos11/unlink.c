--- src/dos11/unlink.c	2021-10-21 22:57:07.000000000 +0100
+++ ../../../aztec42/src/dos11/unlink.c	2021-10-21 17:20:19.000000000 +0100
@@ -3,7 +3,7 @@
 unlink(name)
 char *name;
 {
-	struct fcb delfcb;
+	struct dos_fcb delfcb;
 
 	fcbinit(name,&delfcb);
 	return bdos(DELFIL,&delfcb);
