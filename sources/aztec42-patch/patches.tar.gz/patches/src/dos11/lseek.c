--- src/dos11/lseek.c	2021-10-21 22:57:07.000000000 +0100
+++ ../../../aztec42/src/dos11/lseek.c	2021-10-21 17:20:19.000000000 +0100
@@ -11,14 +11,14 @@
 		errno = EBADF;
 		return -1L;
 	}
-	fp = chantab[fd].c_arg;
+	fp = (struct fcbtab*)chantab[fd].c_arg;
 
 	switch (how) {
 	case 2:
-		pos += fp->fcb.f_size;
+		pos += fp->fcb.dos.f_size;
 		break;
 	case 1:
-		pos += fp->fcb.f_record;
+		pos += fp->fcb.dos.f_record;
 	case 0:
 		break;
 
@@ -28,11 +28,11 @@
 	}
 
 	if (pos < 0) {
-		fp->fcb.f_record = 0;
+		fp->fcb.dos.f_record = 0;
 		errno = EINVAL;
 		return -1L;
 	}
-	fp->fcb.f_record = pos;
+	fp->fcb.dos.f_record = pos;
 	return pos;
 }
 
