--- src/stdio/fopen.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/stdio/fopen.c	2021-10-21 21:23:54.000000000 +0100
@@ -22,7 +22,7 @@
 
 FILE *
 fopen(name,mode)
-char *name,*mode;
+const char *name,*mode;
 {
 	register FILE *fp;
 	FILE *newstream(), *freopen();
@@ -34,7 +34,7 @@
 
 FILE *
 freopen(name, mode, fp)
-char *name,*mode; FILE *fp;
+const char *name,*mode; FILE *fp;
 {
 	register struct modes *mp;
 	register int fd;
