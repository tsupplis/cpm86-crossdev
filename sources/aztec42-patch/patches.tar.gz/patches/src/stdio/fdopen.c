--- src/stdio/fdopen.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/stdio/fdopen.c	2021-10-21 21:23:54.000000000 +0100
@@ -3,7 +3,7 @@
 
 FILE *
 fdopen(fd,mode)
-char *mode;
+const char *mode;
 {
 	register FILE *fp;
 	FILE *newstream();
