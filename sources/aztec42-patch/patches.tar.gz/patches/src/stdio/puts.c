--- src/stdio/puts.c	2021-10-21 22:57:10.000000000 +0100
+++ ../../../aztec42/src/stdio/puts.c	2021-10-21 17:20:19.000000000 +0100
@@ -1,10 +1,12 @@
 /* Copyright (C) 1981,1982 by Manx Software Systems */
+#include <stdio.h>
 
-puts(str)
-register char *str;
+int puts(register char *str)
 {
 	while (*str)
 		if (putchar(*str++) == -1)
 			return -1;
-	return putchar('\n');
+    if (putchar('\n') == -1)
+		return -1;
+	return 0;
 }
