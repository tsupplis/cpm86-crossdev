--- src/screen/scr_home.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_home.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,9 +2,9 @@
 /*
  *	Homes the cursor (0, 0)
  */
+#include <screen.h>
 
-scr_home()
+void scr_home()
 {
 	scr_curs(0, 0);
-	return(0);
 }
