--- src/screen/scr_echo.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_echo.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,12 +2,11 @@
 /*
  *	if flg is zero disable echoing of characters
  */
+#include <screen.h>
 
 extern int _echo;
 
-scr_echo(flg)
-int flg;
+void scr_echo(int flg)
 {
 	_echo = flg;
-	return(0);
 }
