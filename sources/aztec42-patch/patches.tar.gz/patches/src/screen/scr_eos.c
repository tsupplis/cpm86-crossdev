--- src/screen/scr_eos.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_eos.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,14 +2,14 @@
 /*
  *		clear to end of screen
  */
+#include <screen.h>
 
 extern int _attrib;
 
-scr_eos()
+void scr_eos()
 {
 	int lin, col;
 
 	scr_loc(&lin, &col);
 	scr_call(0x920, _attrib, (80-col)+((24-lin)*80), 0);
-	return(0);
 }
