--- src/screen/scr_putc.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_putc.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,11 +2,11 @@
 /*
  *	display the character at the cursor
  */
+#include <screen.h>
 
 int _attrib = 0x07;
 
-scr_putc(c)
-register int c;
+int scr_putc(register int c)
 {
 	c &= 255;
 	if (c >= 0x20)
