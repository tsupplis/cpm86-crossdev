--- src/screen/scr_cdel.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_cdel.c	2021-10-21 17:20:19.000000000 +0100
@@ -7,7 +7,7 @@
 
 extern int _attrib;
 
-scr_cdelete()
+int scr_cdelete()
 {
 	register unsigned ch, x;
 	int lin, col;
@@ -22,5 +22,4 @@
 	scr_curs(lin, max_width-1);
 	scr_call(0x920, _attrib, 1, 0);	/* put a blank at end of line */
 	scr_curs(lin, col);
-	return(0);
 }
