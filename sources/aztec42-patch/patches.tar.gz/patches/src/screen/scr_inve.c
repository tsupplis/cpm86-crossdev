--- src/screen/scr_inve.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_inve.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,12 +2,11 @@
 /*
  * 	if flg is zero turn on inverse
  */
+#include <screen.h>
 
 extern int _attrib;
 
-scr_invers(flg)
-int flg;
+void scr_invers(int flg)
 {
 	_attrib = flg ? 0x70 : 0x07;
-	return(0);
 }
