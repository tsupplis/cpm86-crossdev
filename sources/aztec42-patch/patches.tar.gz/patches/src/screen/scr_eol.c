--- src/screen/scr_eol.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_eol.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,14 +2,14 @@
 /*
  *		Clear to the end of line
  */
+#include <screen.h>
 
 extern int _attrib;
 
-scr_eol()
+void scr_eol()
 {
 	int lin, col;
 
 	scr_loc(&lin, &col);
 	scr_call(0x920, _attrib, 80-col, 0);
-	return(0);
 }
