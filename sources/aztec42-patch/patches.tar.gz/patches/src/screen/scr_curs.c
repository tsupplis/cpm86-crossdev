--- src/screen/scr_curs.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_curs.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,16 +2,31 @@
 /*
  * 	Moves cursor to line lin, position pos
  */
+#include <screen.h>
 
 #define max_width 80
 
-scr_curs(lin, col)
-register int lin, col;
+void scr_curs(register int lin, register int col)
 {
 	if (col >= max_width)
 		col = max_width - 1;
 	if (lin >= 25)
 		lin = 24;
 	scr_call(0x200, 0, 0, (lin << 8) | col);
-	return(0);
+}
+
+int scr_line() {
+	int line;
+	int col;
+
+	scr_loc(&line,&col);
+	return line;
+}
+
+int scr_col() {
+	int line;
+	int col;
+
+	scr_loc(&line,&col);
+	return line;
 }
