--- src/screen/scr_cins.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_cins.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,11 +2,12 @@
 /*
  *	insert a space at the cursor and delete the char. at end of line
  */
+#include <screen.h>
 
 #define max_width 80
 extern int _attrib;
 
-scr_cinsert()
+void scr_cinsert()
 {
 	register unsigned ch, z;
 	int lin, col;
@@ -20,5 +21,4 @@
 	}
 	scr_curs(lin, col);
 	scr_call(0x920,_attrib,1,0);
-	return(0);
 }
