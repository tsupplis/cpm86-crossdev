--- src/screen/scr_clea.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_clea.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,15 +2,16 @@
 /*
  *	Clears the screen and homes the cursor
  */
+#include <screen.h>
 
 #define max_width  80
 #define max_y  25
 
 extern int _attrib;
 
-scr_clear()
+void scr_clear()
 {
 	scr_home();
 	scr_call(0x920,_attrib,(max_width * max_y),0);
-	return(0);
+	scr_home();
 }
