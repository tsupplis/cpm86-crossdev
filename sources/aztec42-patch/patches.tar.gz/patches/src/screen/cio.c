--- src/screen/cio.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/cio.c	2021-10-21 17:20:19.000000000 +0100
@@ -1,7 +1,9 @@
+#include <screen.h>
+#include <stdarg.h>
+
 extern int _attrib;
 
-static cputc(chr)
-register int chr;
+static void cputc(register int chr)
 {
 	scr_putc(chr);
 	
@@ -9,25 +11,25 @@
 		scr_putc('\r');
 }
 
-scr_puts(str)
-register char *str;
+int scr_puts(register const char * str)
 {
 	while(*str)
 		cputc(*str++);
-
-	cputc('\n');
 }
 
-scr_printf(fmt,args)
-register char *fmt; 
-unsigned args;
+int scr_printf (const char *fmt, ...)
 {
-	format(cputc,fmt,&args);
+	register va_list vargs;
+	register int ret;
+
+	va_start (vargs, fmt);
+	ret = format(cputc,fmt,vargs);
+	va_end (vargs);
+	return (ret);
 }
 
-scr_setatr(back,frg,intens,blink)
-register int back, frg;
-register int intens, blink;
+scr_setattr(register int back, register int frg,
+register int intens, register int blink)
 {
 	register char tmp;
 	
@@ -48,17 +50,16 @@
 	return(tmp);
 }
 
-scr_getatr()
+int scr_getattr()
 {
 	return(_attrib);
 }
 
-scr_resatr(atr)
-register int atr;
+int scr_resattr(register int attr)
 {
 	register char tmp;
 	
 	tmp = _attrib;
-	_attrib = atr;
+	_attrib = attr;
 	return(tmp);
 }
