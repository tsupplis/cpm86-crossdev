--- src/cpm86/read.c	2021-10-21 22:57:07.000000000 +0100
+++ ../../../aztec42/src/cpm86/read.c	2021-10-21 17:20:19.000000000 +0100
@@ -3,10 +3,10 @@
 #include "errno.h"
 #include "fcntl.h"
 
-int bdf_(), filerd(), tty_rd(), bdosrd();
+int badfd(), filerd(), tty_rd(), bdosrd();
 
 int (*Rd_tab[])() = {
-	bdf_, filerd, tty_rd, bdosrd,
+	badfd, filerd, tty_rd, bdosrd,
 };
 extern int errno;
 
