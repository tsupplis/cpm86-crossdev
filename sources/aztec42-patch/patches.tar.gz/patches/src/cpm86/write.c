--- src/cpm86/write.c	2021-10-21 22:57:07.000000000 +0100
+++ ../../../aztec42/src/cpm86/write.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,10 +2,10 @@
 #include "io.h"
 #include "errno.h"
 
-int tty_wr(), bdoswr(), filewr(), bdf_();
+int tty_wr(), bdoswr(), filewr(), badfd();
 
 int (*Wrt_tab[])() = {
-	bdf_, filewr, bdoswr, bdoswr
+	badfd, filewr, bdoswr, bdoswr
 };
 
 write(fd, buff, len)
