--- src/cpm86/croot.c	2021-10-21 22:57:07.000000000 +0100
+++ ../../../aztec42/src/cpm86/croot.c	2021-10-21 17:20:19.000000000 +0100
@@ -3,30 +3,14 @@
 #include "fcntl.h"
 #include "io.h"
 
-int bdf_(), ret_();
-
-/*
- * channel table: relates fd's to devices
- */
-struct channel chantab[] = {
-	{ 2, 0, 1, 0, ret_, (_arg)2 },
-	{ 0, 2, 1, 0, ret_, (_arg)2 },
-	{ 0, 2, 1, 0, ret_, (_arg)2 },
-	{ 0, 0, 0, 0, bdf_, (_arg)0 },
-	{ 0, 0, 0, 0, bdf_, (_arg)0 },
-	{ 0, 0, 0, 0, bdf_, (_arg)0 },
-	{ 0, 0, 0, 0, bdf_, (_arg)0 },
-	{ 0, 0, 0, 0, bdf_, (_arg)0 },
-	{ 0, 0, 0, 0, bdf_, (_arg)0 },
-	{ 0, 0, 0, 0, bdf_, (_arg)0 },
-	{ 0, 0, 0, 0, bdf_, (_arg)0 },
-};
+int badfd();
+int noper();
 
 #define MAXARGS 30
 static char *Argv[MAXARGS];
 static char Argbuf[128];
 static int Argc;
-int (*cls_)() = ret_;
+int (*cls_)() = noper;
 
 Croot()
 {
@@ -97,14 +81,3 @@
 	_exit();
 }
 
-bdf_()
-{
-	errno = EBADF;
-	return -1;
-}
-
-ret_()
-{
-	return 0;
-}
-
