--- include/cpm.h	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/include/cpm.h	2021-10-21 15:17:54.000000000 +0100
@@ -0,0 +1,11 @@
+/* Copyright 1992 Manx Software Systems, Inc. All rights reserved */
+
+#ifndef __CPM_H
+#define	__CPM_H
+
+int bdos(int _func, int _dx);
+int dup(int _oldfd);
+int fcbinit(char *_name, void *_fcb);
+int fdup(int _oldfd, int _newfd);
+
+#endif	/* __CPM_H */
