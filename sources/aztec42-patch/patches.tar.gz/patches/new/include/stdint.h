--- include/stdint.h	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/include/stdint.h	2021-10-21 15:17:54.000000000 +0100
@@ -0,0 +1,22 @@
+#ifndef __STDINT_H
+#define __STDINT_H
+
+typedef signed char		int8_t;
+typedef int			int16_t;
+typedef long int		int32_t;
+
+typedef unsigned char		uint8_t;
+typedef unsigned int		uint16_t;
+typedef unsigned long		uint32_t;
+
+# define INT8_MIN		(-128)
+# define INT16_MIN		(-32767-1)
+# define INT32_MIN		(-2147483647-1)
+# define INT8_MAX		(127)
+# define INT16_MAX		(32767)
+# define INT32_MAX		(2147483647)
+# define UINT8_MAX		(255)
+# define UINT16_MAX		(65535)
+# define UINT32_MAX		(4294967295U)
+
+#endif 
