--- src/dos11/access.c	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/src/dos11/access.c	2021-10-21 17:20:19.000000000 +0100
@@ -0,0 +1,17 @@
+/* Copyright (C) 1982 by Manx Software Systems */
+#include "errno.h"
+#include "fcntl.h"
+#include "io.h"
+
+access(path, amode)
+char *path;
+{
+	register int fd;
+
+	if ((fd = open(path, amode&2 ? 1 : 0)) != -1) {
+		close(fd);
+		fd = 0;
+	}
+	return fd;
+}
+
