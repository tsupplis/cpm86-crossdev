--- src/dos11/os.c	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/src/dos11/os.c	2021-10-21 17:20:19.000000000 +0100
@@ -0,0 +1,5 @@
+#include <fcntl.h>
+
+int os() {
+	return OS_MSDOS11;
+}
