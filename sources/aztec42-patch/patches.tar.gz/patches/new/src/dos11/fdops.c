--- src/dos11/fdops.c	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/src/dos11/fdops.c	2021-10-21 17:20:19.000000000 +0100
@@ -0,0 +1,32 @@
+/* Copyright (C) 1981,1982, 1983 by Manx Software Systems */
+#include "fcntl.h"
+#include "errno.h"
+#include "io.h"
+
+int badfd()
+{
+	errno = EBADF;
+	return -1;
+}
+
+int noper()
+{
+	return 0;
+}
+/*
+ * channel table: relates fd's to devices
+ */
+struct channel  chantab[] = {
+	{ 2, 0, 1, 0, noper, (_arg)2 },
+	{ 0, 2, 1, 0, noper, (_arg)2 },
+	{ 0, 2, 1, 0, noper, (_arg)2 },
+	{ 0, 0, 0, 0, badfd, (_arg)0 },
+	{ 0, 0, 0, 0, badfd, (_arg)0 },
+	{ 0, 0, 0, 0, badfd, (_arg)0 },
+	{ 0, 0, 0, 0, badfd, (_arg)0 },
+	{ 0, 0, 0, 0, badfd, (_arg)0 },
+	{ 0, 0, 0, 0, badfd, (_arg)0 },
+	{ 0, 0, 0, 0, badfd, (_arg)0 },
+	{ 0, 0, 0, 0, badfd, (_arg)0 },
+};
+
