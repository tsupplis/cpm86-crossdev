--- src/hello.c	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/src/hello.c	2021-10-21 17:20:19.000000000 +0100
@@ -0,0 +1,52 @@
+#include <stdio.h>
+#include <fcntl.h>
+
+void pad(FILE* f) {
+    int i;
+    long delta;
+    delta=128-(ftell(f)%128);
+    for(i=0;i<delta;i++) {
+        putc(0x1A,f);
+    }
+}
+
+int r_main() {
+    FILE *f;
+
+    putchar('!');
+    puts("Hello .");
+    puts("Writing file 'text.dat' ...");
+    unlink("text.dat");
+    f=fopen("text.dat","w");
+    if(f) {
+        if(!fwrite("Hello\n",1,strlen("Hello\n"),f)) {
+            printf("Fwrite failed ...\r\n");
+        }
+        fprintf(f,"Wow\n");
+        fprintf(f,"Wow\n");
+        fprintf(f,"Wow\n");
+        fprintf(f,"%c",26);
+        printf("current position: %lu\n",ftell(f));
+        pad(f);
+        fclose(f);
+    } else {
+        puts("Failed to open 'text.dat' ...\n");
+    }
+    puts("Reading file 'text.dat' ...");
+    f=fopen("text.dat","r");
+    if(f) {
+        int c;
+        while((c=fgetc(f))!=EOF) {
+            putchar(c);
+        }
+        fclose(f);
+    } else {
+        puts("Failed to open 'text.dat' ...");
+    }
+    return 2;
+}
+
+int main() {
+    exit(r_main());
+    return 0;
+}
