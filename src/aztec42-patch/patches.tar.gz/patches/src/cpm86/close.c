--- src/cpm86/close.c	2021-10-21 22:57:07.000000000 +0100
+++ ../../../aztec42/src/cpm86/close.c	2021-10-21 17:20:19.000000000 +0100
@@ -5,7 +5,7 @@
 close(fd)
 {
 	register struct channel *chp;
-	extern int bdf_();
+	extern int badfd();
 
 	if (fd < 0 || fd > MAXCHAN) {
 		errno = EBADF;
@@ -14,6 +14,6 @@
 	chp = &chantab[fd];
 	fd = (*chp->c_close)(chp->c_arg);
 	chp->c_read = chp->c_write = chp->c_ioctl = chp->c_seek = 0;
-	chp->c_close = bdf_;
+	chp->c_close = badfd;
 	return fd;
 }
