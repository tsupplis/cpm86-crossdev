--- src/cpm86/lseek.c	2026-08-24 20:35:05.036741249 -0400
+++ ../../../aztec42/src/cpm86/lseek.c	2026-08-24 20:12:39.802171145 -0400
@@ -1,49 +1,219 @@
 /* Copyright (C) 1982, 1984 by Manx Software Systems */
+/* Copyright (c) 2026 Jeffrey H. Johnson <johnsonjh.dev@gmail.com> */
+
 #include "io.h"
 #include "errno.h"
 
-long lseek(fd, pos, how)
+extern int bdos();
+
+/* Fallback if we need to walk using BDOS 15/20/16. */
+static long
+_cpm_walk_file(fp)
+register struct fcbtab *fp;
+{
+        unsigned char fcb[36];
+        int i;
+        unsigned rc;
+        long count;
+
+        /* Copy live FCB into local buffer! */
+        for (i = 0; i < 36; i++)
+                fcb[i] = ((unsigned char *)&fp->fcb)[i];
+
+        /* BDOS 15: open file */
+        rc = bdos(15, fcb);
+        if ((rc & 0xFF) == 0xFF)
+                return -1L;
+
+        count = 0L;
+
+        /* BDOS 20 - read sequential, 1 record per successful read! */
+        for (;;) {
+                rc = bdos(20, fcb);
+                if ((rc & 0xFF) != 0)
+                        break;
+                count += 128L;
+        }
+
+        /* BDOS 16 - close */
+        bdos(16, fcb);
+
+        return count;
+}
+
+/*
+ * Compute file size using LRBC + record count via BDOS 35.
+ *
+ *  >=0 - size
+ *   -2 - records == 0 && lrbc > 0 (bug detect)
+ *   -1 - LRBC not available or unusable
+ *
+ * For success (or bug detect) *plrbc is set to the LRBC value.
+ */
+static long
+_cpm_lrbc_size(fp, plrbc)
+register struct fcbtab *fp;
+int *plrbc;
+{
+        unsigned char fcb[36];
+        long records, last_ext;
+        int lrbc;
+        long size;
+        int i;
+        unsigned rc;
+
+        /* Copy live FCB, important! */
+        for (i = 0; i < 36; i++)
+                fcb[i] = ((unsigned char *)&fp->fcb)[i];
+
+        /* BDOS 35 - F_SIZE (compute file size into R0/R1/R2) */
+        rc = bdos(35, fcb);
+        if ((rc & 0xFF) == 0xFF)
+                return -1L;
+
+        records = ((long)(fcb[33] & 0xFF))
+                | ((long)(fcb[34] & 0xFF) << 8)
+                | ((long)(fcb[35] & 0xFF) << 16);
+
+        for (i = 0; i < 36; i++)
+                fcb[i] = ((unsigned char *)&fp->fcb)[i];
+
+        last_ext = (records > 0L) ? ((records - 1L) >> 7) : 0L;
+
+        fcb[12] = (unsigned char)(last_ext & 0x1f);        /* EX */
+        fcb[13] = 0;                                       /* S1 */
+        fcb[14] = (unsigned char)((last_ext >> 5) & 0x3f); /* S2 */
+        fcb[32] = 0xFF;                                    /* CR */
+
+        rc = bdos(15, fcb);
+        if ((rc & 0xFF) == 0xFF) {
+                lrbc = 0;
+        } else {
+                lrbc = fcb[32] & 0xFF;
+                fcb[32] = 0x00;
+                bdos(16, fcb);
+        }
+
+        if (plrbc != 0)
+                *plrbc = lrbc;
+
+        /* Bug detected! records == 0 but LRBC > 0 */
+        if (records == 0L && lrbc > 0)
+                return -2L;
+
+        /* both zero? unusable! */
+        if (records == 0L && lrbc == 0)
+                return -1L;
+
+        if (lrbc > 0)
+                size = (records - 1L) * 128L + lrbc;
+        else
+                size = records * 128L;
+
+        if (size <= 0L)
+                return -1L;
+
+        return size;
+}
+
+long
+lseek(fd, pos, how)
 long pos;
 {
-	register struct fcbtab *fp;
+        register struct fcbtab *fp;
+        long endpos;
+        int lrbc;
 
-	if (chantab[fd].c_seek == 0) {
+        if (chantab[fd].c_seek == 0) {
 Badf:
-		errno = EBADF;
-		return -1L;
-	}
-	fp = (struct fcbtab *)chantab[fd].c_arg;
-
-	switch (how) {
-	case 2:
-		/*
-		 * Close the file because CP/M doesn't know how big an open file is.
-		 * However, the fcb is still valid.
-		 */
-		setusr(fp->user);
-		fp->fcb.f_name[4] |= 0x80;	/* set parital close flag for MP/M */
-		bdos(CLSFIL, &fp->fcb);
-		fp->fcb.f_name[4] &= 0x7f;	/* clear parital close flag */
-		_Ceof(fp);
-		rstusr();
-	case 1:
-		pos += fp->offset + ((long)fp->fcb.f_record << 7);
-	case 0:
-		break;
-
-	default:
-		errno = EINVAL;
-		return -1L;
-	}
-
-	fp->fcb.f_overfl = 0;
-	if (pos < 0) {
-		fp->offset = fp->fcb.f_record = 0;
-		errno = EINVAL;
-		return -1L;
-	}
-	fp->offset = (unsigned)pos & 127;
-	fp->fcb.f_record = pos >> 7;
-	return pos;
-}
+                errno = EBADF;
+                return -1L;
+        }
+
+        fp = (struct fcbtab *)chantab[fd].c_arg;
+
+        switch (how) {
+
+        case 2:
+                /*
+                 * Manx "closes" the file because CP/M doesn't know how big an
+                 * open file is, However, the fcb is still (and remains) valid.
+                 */
+                setusr(fp->user);
+                fp->fcb.f_name[4] |= 0x80;      /* set partial close flag for MP/M */
+                bdos(CLSFIL, &fp->fcb);
+                fp->fcb.f_name[4] &= 0x7f;      /* clear partial close flag */
+
+                /*
+                 * First try LRBC + record count.
+                 */
+                endpos = _cpm_lrbc_size(fp, &lrbc);
+
+                if (endpos >= 0L) {
+                        /* Normal LRBC case: endpos correct */
+                } else if (endpos == -2L) {
+                        /*
+                         * Bug detected, use workaround:
+                         *   records == 0 && lrbc > 0, so derived size
+                         *     = (records-1)*128 + lrbc is negative.
+                         *
+                         * Fallback to walking file to get slack size,
+                         * then subtract (128 - lrbc) to get the true EOF.
+                         */
+                        long slack;
+
+                        slack = _cpm_walk_file(fp);
+                        if (slack < 0L) {
+                                _Ceof(fp);
+                                endpos = fp->offset + ((long)fp->fcb.f_record << 7);
+                        } else {
+                                endpos = slack - (128L - (long)lrbc);
+                                if (endpos < 0L)
+                                        endpos = 0L;
+                        }
+                } else {
+                        /*
+                         * LRBC not available or otherwise unusable?
+                         * Walk file to get slack size, and includes last slack record!
+                         */
+                        long slack;
+
+                        slack = _cpm_walk_file(fp);
+                        if (slack < 0L) {
+                                _Ceof(fp);
+                                endpos = fp->offset + ((long)fp->fcb.f_record << 7);
+                        } else {
+                                endpos = slack;
+                        }
+                }
+
+                rstusr();
+
+                pos += endpos;
+                break;
+
+        case 1:
+                pos += fp->offset + ((long)fp->fcb.f_record << 7);
+                break;
+
+        case 0:
+                break;
+
+        default:
+                errno = EINVAL;
+                return -1L;
+        }
+
+        fp->fcb.f_overfl = 0;
+
+        if (pos < 0) {
+                fp->offset = fp->fcb.f_record = 0;
+                errno = EINVAL;
+                return -1L;
+        }
+
+        fp->offset = (unsigned)pos & 127;
+        fp->fcb.f_record = pos >> 7;
 
+        return pos;
+}
