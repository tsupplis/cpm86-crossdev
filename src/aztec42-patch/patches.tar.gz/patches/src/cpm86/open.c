--- src/cpm86/open.c	2021-10-21 22:57:07.000000000 +0100
+++ ../../../aztec42/src/cpm86/open.c	2021-10-21 17:20:19.000000000 +0100
@@ -4,14 +4,14 @@
 #include "io.h"
 
 #define MAXFILE	8	/* maximum number of open DISK files */
-int bdf_(), ret_(), fileop();
+int badfd(), noper(), fileop();
 /*
  * note: The ioctl function knows that the condev read/write numbers are
  * 2.  It uses this information to patch the read/write tables.
  */
-static struct device condev = { 2, 2, 1, 0, ret_ };
-static struct device bdosout= { 0, 3, 0, 0, ret_ };
-static struct device bdosin = { 3, 0, 0, 0, ret_ };
+static struct device condev = { 2, 2, 1, 0, noper };
+static struct device bdosout= { 0, 3, 0, 0, noper };
+static struct device bdosin = { 3, 0, 0, 0, noper };
 static struct device filedev= { 1, 1, 0, 1, fileop };
 
 /*
@@ -47,7 +47,7 @@
 	int fd, mdmask;
 
 	for (chp = chantab, fd = 0 ; fd < MAXCHAN ; ++chp, ++fd)
-		if (chp->c_close == bdf_)
+		if (chp->c_close == badfd)
 			goto fndchan;
 	errno = EMFILE;
 	return -1;
@@ -73,9 +73,9 @@
 	chp->c_arg = dp->d_arg;
 	chp->c_ioctl = dev->d_ioctl;
 	chp->c_seek = dev->d_seek;
-	chp->c_close = ret_;
+	chp->c_close = noper;
 	if ((*dev->d_open)(name, flag, mode, chp, dp) < 0) {
-		chp->c_close = bdf_;
+		chp->c_close = badfd;
 		return -1;
 	}
 	return fd;
