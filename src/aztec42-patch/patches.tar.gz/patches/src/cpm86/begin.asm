--- src/cpm86/begin.asm	2021-10-21 22:57:10.000000000 +0100
+++ ../../../aztec42/src/cpm86/begin.asm	2021-10-21 17:20:19.000000000 +0100
@@ -2,16 +2,15 @@
 ; :ts=8
 codeseg	segment	word public 'code'
 	public	$MEMRY
-	public	_mbot_, _sbot_
+	public	_mbot_, _sbot_, _lowwater_
 dataseg	segment	word public 'data'
 $MEMRY	dw	-1
-	public	errno_
-errno_	dw	0
 	public	_dsval_,_csval_
 _dsval_	dw	0
 _csval_	dw	0
 _mbot_	dw	0
 _sbot_	dw	0
+_lowwater_	dw	-1
 exitad	dw	0
 exitcs	dw	0
 bad8087	db	"8087/80287 is required!",13,10,'$'
