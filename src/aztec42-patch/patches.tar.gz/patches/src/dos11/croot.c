--- src/dos11/croot.c	2021-10-21 22:57:07.000000000 +0100
+++ ../../../aztec42/src/dos11/croot.c	2021-10-21 17:20:19.000000000 +0100
@@ -3,35 +3,13 @@
 #include "fcntl.h"
 #include "io.h"
 
-badfd()
-{
-	errno = EBADF;
-	return -1;
-}
+int badfd();
 
-noper()
-{
-	return 0;
-}
+int noper();
 
-int (*cls_)() = noper;
+void exit(int code);
 
-/*
- * channel table: relates fd's to devices
- */
-struct channel  chantab[] = {
-	{ 2, 0, 1, 0, noper, 2 },
-	{ 0, 2, 1, 0, noper, 2 },
-	{ 0, 2, 1, 0, noper, 2 },
-	{ 0, 0, 0, 0, badfd, 0 },
-	{ 0, 0, 0, 0, badfd, 0 },
-	{ 0, 0, 0, 0, badfd, 0 },
-	{ 0, 0, 0, 0, badfd, 0 },
-	{ 0, 0, 0, 0, badfd, 0 },
-	{ 0, 0, 0, 0, badfd, 0 },
-	{ 0, 0, 0, 0, badfd, 0 },
-	{ 0, 0, 0, 0, badfd, 0 },
-};
+int (*cls_)() = noper;
 
 #define MAXARGS 30
 static char *Argv[MAXARGS];
@@ -101,7 +79,7 @@
 }
 #endif
 
-exit(code)
+void exit(int code)
 {
 	register int fd;
 
