--- src/dos11/begin.asm	2022-02-25 03:42:10.000000000 +0000
+++ ../../../aztec42/src/dos11/begin.asm	2022-02-25 03:13:04.000000000 +0000
@@ -2,11 +2,9 @@
 ; :ts=8
 codeseg	segment	para public 'code'
 	public	$MEMRY
-	public	_mbot_, _sbot_
+	public	_mbot_, _sbot_, _lowwater_
 dataseg	segment	para public 'data'
 $MEMRY	dw	-1
-	public	errno_
-errno_	dw	0
 	public	_dsval_,_csval_
 _dsval_	dw	0
 _csval_	dw	0
@@ -14,6 +12,7 @@
 _Dmaseg_ dw	0
 _mbot_	dw	0
 _sbot_	dw	0
+_lowwater_	dw	-1
 	extrn	_Uorg_:byte,_Uend_:byte
 dataseg	ends
 	public	exitad, exitcs
@@ -86,7 +85,7 @@
 	pop	ax		;fetch return code
 	test	ax,ax
 	jz	exit
-	int	23h		;use int 23 handler for non-zero exits
+	int	20h		;use int 20 handler for non-zero exits
 exit:
 	jmp	dword ptr exitad
 $begin	endp
