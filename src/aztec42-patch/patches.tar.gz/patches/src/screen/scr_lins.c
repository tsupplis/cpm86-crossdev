--- src/screen/scr_lins.c	2021-10-21 22:57:09.000000000 +0100
+++ ../../../aztec42/src/screen/scr_lins.c	2021-10-21 17:20:19.000000000 +0100
@@ -2,15 +2,15 @@
 /*
  *	Inserts blank lines at lin, pushing rest down
  */
+#include <screen.h>
 
 extern int _attrib;
 
-scr_linsert()
+void scr_linsert()
 {
 	int lin, col;
 
 	scr_loc(&lin, &col);
 	scr_call(0x700 | 1, _attrib<<8, lin<<8, (24<<8) | 79);
 	scr_curs(lin, 0);
-	return(0);
 }
