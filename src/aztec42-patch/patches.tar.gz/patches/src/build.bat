--- src/build.bat	2021-10-21 22:57:06.000000000 +0100
+++ ../../../aztec42/src/build.bat	2021-10-21 19:16:07.000000000 +0100
@@ -1,4 +1,5 @@
-echo off
+@echo off
+PATH=..\bin;%PATH%
 if NOT '%1'=='RESTART' goto makeall
 shift
 goto %RESTART%
@@ -7,6 +8,9 @@
 :SMALL
 set RESTART=SMALL
 make MODEL= AMODEL=0 %1 %2 %3 %4 %5 %6
+make MODEL= AMODEL=0 ovly
+make MODEL= AMODEL=0 cpm
+make MODEL= AMODEL=0 d11
 if ERRORLEVEL 1 goto quit
 make clean
 :COMPACT
