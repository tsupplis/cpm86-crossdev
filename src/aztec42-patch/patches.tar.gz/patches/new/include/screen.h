--- include/screen.h	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/include/screen.h	2021-10-21 15:17:54.000000000 +0100
@@ -0,0 +1,31 @@
+#ifndef __SCREEN_H
+#define __SCREEN_H
+
+int scr_putc(register int c);
+int scr_puts(register const char * str);
+int scr_printf(const char *fmt, ...);
+int scr_setattr(register int back,register int frg,
+        register int intens,register int blink);
+int scr_getattr();
+int scr_resattr(register int atr);
+void scr_clear();
+void scr_home();
+void scr_curs(register int line, register int col);
+void scr_cdelete();
+void scr_cinsert();
+void scr_ldelete();
+void scr_linsert();
+void scr_invers(int flg);
+void scr_eos();
+void scr_eol();
+int scr_getck();
+int scr_getch();
+int scr_ungetch();
+int scr_getche();
+int scr_kbhit();
+int scr_pollk();
+void scr_loc(int *line, int *col);
+int scr_line();
+int scr_col();
+
+#endif
