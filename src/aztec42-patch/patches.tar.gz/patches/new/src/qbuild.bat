--- src/qbuild.bat	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/src/qbuild.bat	2021-10-21 17:20:19.000000000 +0100
@@ -0,0 +1 @@
+make MODE= AMDODE=0 d11 cpm
