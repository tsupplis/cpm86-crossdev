--- src/simple.c	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/src/simple.c	2021-10-21 17:20:19.000000000 +0100
@@ -0,0 +1,6 @@
+#include <stdio.h>
+
+int main() {
+	printf("hello\n");
+	return 0;
+}
