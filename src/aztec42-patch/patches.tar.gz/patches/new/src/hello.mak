--- src/hello.mak	1970-01-01 01:00:00.000000000 +0100
+++ ../../../aztec42/src/hello.mak	2021-10-21 17:20:19.000000000 +0100
@@ -0,0 +1,33 @@
+all: hello.com hello.cmd hello1.com \
+   simple.com simple.cmd simple1.com
+
+simple.cmd: simple.o
+	ln -o simple.cmd simple.o -lc86
+
+simple1.com: simple.o
+	ln -o simple1.com simple.o -ld11
+
+simple.com: simple.o
+	ln -o simple.com simple.o -lc
+
+simple.o: simple.c
+	cc -B +c -o simple.o simple.c
+	sqz simple.o
+
+hello.cmd: hello.o
+	ln -o hello.cmd hello.o -lc86
+
+hello1.com: hello.o
+	ln -o hello1.com hello.o -ld11
+
+hello.com: hello.o
+	ln -o hello.com hello.o -lc 
+
+hello.o: hello.c
+	cc -B +c -o hello.o +0 hello.c
+	sqz hello.o
+
+clean:
+	del *.o
+	del *.com
+	del *.cmd
