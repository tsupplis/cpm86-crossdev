--- include/errno.h	2021-10-21 22:56:04.000000000 +0100
+++ ../../../aztec42/include/errno.h	2021-10-21 15:17:54.000000000 +0100
@@ -1,3 +1,5 @@
+#ifndef __ERRNO_H
+#define __ERRNO_H
 extern int errno;
 extern char *sys_errlist[];
 extern int sys_nerr;
@@ -27,3 +29,5 @@
 /* used by the math library */
 #define ERANGE	21
 #define EDOM	22
+
+#endif
